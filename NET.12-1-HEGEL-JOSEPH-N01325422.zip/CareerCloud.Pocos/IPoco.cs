﻿using System;

namespace CareerCloud.Pocos
{
    interface IPoco
    {
        Guid Id { get; set; }
    }
}
